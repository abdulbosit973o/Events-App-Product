package uz.gita.bootcamp.abdulbosit.apps.util

import android.util.Log

fun String.log(tag: String = "TTT") { Log.d(tag, this) }